CS401
DP Circuit-Tree
Shane Lopez


Unfortunately I was unable to complete my implementation on time, though within my .cpp I have left comments (nearer the bottom)
explaining my thought process and the way in which my algorithm is intended to work. I believe that if I had had just a little 
more time, I would have gotten it to work, although in truth I am not so sure my algorithm is optimal; this fact stems, I believe, 
from the lack of comparison of aggregated delays with respect to both neighboring inputs; I check to see if the left delay is within a 
certain range, act if it is, and proceed to update my info and evaluate the right neighbor in the same fashion. I have a sneaking 
suspicion that it would be better advised to evaluate both neighbors before making a gate coupling, but as mentioned, time does not 
allow for those tweaks at present. However, I hope that my comments and coding will count for something! :D


Building
	$ make


Running
	$./gtree <input file> <gate delay>



