#include "helper.h"

using namespace std;

int main(int argc, char** argv) {
	//Introduction
	cout<<"*******************************************"<<endl;
	cout<<"Project: Find My Stuff!\nAuthor: Shane Lopez"<<endl;
	cout<<"*******************************************\n"<<endl;
	//Check validity of command before bothering with variables
	if(argc < 1 || argc > MAX_ARGS) {
		cout << "\nUsage: ./findIt [option1] [option2] "
		     << "[option3] [option4] [option5] [option6]\n"<<endl;
		exit(1);
	}
	///////////////////////////////DO WORK//////////////////////////////
	populate(argc,argv); //assign variables based on input
	query();      // Ask for target
	listAll("."); // Scan through file system from current directory
	listMatch();  // List all target matches
	//cout << "\nEND OF PROGRAM" << endl; // Debug
	return 0;
}
