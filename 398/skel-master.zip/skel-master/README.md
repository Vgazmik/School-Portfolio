skel
====

quick program prototypes!
