#ifndef _PT_
#define _PT_
class pt {

	public: 
		int x;
		int y;
		pt();
		pt(int, int);
		void setXY(int, int);
};
#endif
