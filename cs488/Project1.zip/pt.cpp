#include "pt.h"
pt::pt() {
	x = 0;
	y = 0;
}
pt::pt(int x_, int y_) {
	x = x_;
	y = y_;
}	
void pt::setXY(int x_, int y_) {
	x = x_;
	y = y_;
}
